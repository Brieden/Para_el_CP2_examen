import scipy as sci
from scipy.integrate import quad
from scipy.optimize import newton
import pylab as plt
epsilon = 1e-6
m = 0.5

def Period(E, V, m):
    # Turning point is V(x+-) = E
    # For the real potential, it follows x+- = +- arccos(1/E)
    xp=sci.arccos(1/E)
    xm =-xp
    # Integrand of period integral
    integrand = lambda x: 1./sci.sqrt(E-V(x))
    # Calculate period by integration from xm+epsilon to xp-epsilon to avoid zero in denominator of integrand
    return sci.sqrt(2*m) * quad(integrand, xm+epsilon, xp-epsilon)[0]

def CalcPeriod(E, V, m):
    T = sci.zeros(len(E))
    for i in range(len(E)):
        T[i] = Period(E[i], V, m)
    return T
    

#plot integrand for a fixed value of E 
E = 2.
x = sci.linspace(-sci.pi/2+epsilon,sci.pi/2-epsilon,100)
x_range = x[abs(x) <= sci.arccos(1/E)-epsilon] # restrict x to x- < x < x+ for plotting

plt.figure()
plt.plot(x_range/sci.pi,1./sci.sqrt(E-1/sci.cos(x_range)),label='$E=2, \ V = 1/\cos(x)$')
plt.xlabel('$x/\pi$')
plt.ylabel('integrand')
plt.xlim(-0.5,0.5)
plt.legend()

plt.show()

input("Press enter to continue")

E = sci.linspace(1+epsilon,50,200) # choose E such that E-V(x) > 0 to get a real integrand

print("Physical potential")
T = CalcPeriod(E, lambda x: 1/sci.cos(x), m)
print(E[0],T[0])

plt.figure()
plt.plot(E, T, label='$V = 1/\cos(x)$')
plt.xlabel('$E$')
plt.ylabel('$T$')
plt.hold(True)
plt.xlim(0)
plt.ylim(0)
plt.legend()
plt.show()

exit()

