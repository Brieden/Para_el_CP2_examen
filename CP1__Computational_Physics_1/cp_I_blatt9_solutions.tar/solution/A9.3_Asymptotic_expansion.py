import scipy as sci
import numpy as np
import matplotlib.pyplot as plt

N = 20 # number of terms in the asymptotic expansion

def summands(x,N):
    coeff = sci.exp(-x)/x
    S=sci.zeros(N)
    S[0] = -1/x
    for n in range(1,N):
      S[n]=-S[n-1]*n/x # recursive defn for each term in the asymptotic series
    return S*coeff   

x = sci.linspace(1,20,20)
Nvalues = sci.copy(x) 
x*=2
#print(Nvalues)
#print(x)

Sabs = sci.zeros((len(x),N))
for n in range(len(x)):
    Sabs[n][:] = abs(summands(x[n],N))

# min occurs at n=x 
print("Nmin \t x \t |summand|")
#for n in range(len(x)):
for n in range(10):
 idxmin = np.argmin(abs(summands(x[n],N)))  # find first index where |summand| is minimal
 print(Nvalues[idxmin],"\t",x[n],"\t",Sabs[n,idxmin]) 
 
 plt.semilogy(Nvalues,Sabs[n,:]) 
 plt.semilogy(Nvalues[idxmin],Sabs[n,idxmin], 'x', color='black') 

plt.semilogy(Nvalues,sci.exp(-Nvalues*2.33), color='black') # plot exp(-a*n) to illustrate that the minima do not depend exponentially on n
plt.xlabel(r'$n$')
plt.ylabel(r'|summand|')
plt.show()


