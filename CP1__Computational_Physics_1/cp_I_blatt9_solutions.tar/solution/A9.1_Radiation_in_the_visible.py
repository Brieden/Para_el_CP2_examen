import scipy as sci
from scipy import exp, inf
from scipy.integrate import quad
import scipy.constants as c
import pylab as plt
epsilon = 1e-4
T = 5700 # Sun
#T = 20000 # White dwarf

# Planck: Pdv ~ v^3/(exp(hv/kT)-1)dv
# Let U(v1, v2) the radiation in the interval v1, v2
# i.e. U(v1, v2) = int_v1^v2(E(x)dx) with E(x) = x^3/(exp(x)-1)dx
# The fraction of radiation emitted in the visible is then
# f = U(v1, v2)/U(0, oo) where v1 and v2 are the limits of the visible range
# -> constants in U (or E) may therefore be ignored

# Dimensionless units: x = hv/kT

# Plancks radiation law
def E(x):
    return x*x*x/(exp(x)-1)

# lim x->0:
# 3*x**2 -> 0  /  exp(x) -> 1  = 0


# To calculate the integral to infinity, substitute y = 1/x
def E2(y):
    return 1./(y**5)/(exp(1./y)-1)

# lim y->0:
# \approx exp(-1/y) / y**5
# -> 0

# lambda1 = 750nm =>
l1 = c.h * c.c /(c.k * T * 750e-9)   # use scipy.constants 
# lambda2 = 400nm =>
l2 = c.h * c.c /(c.k * T * 400e-9) 

if (T == 5700):
  print("System: Sun")
elif (T== 20000):
  print("System: White dwarf")
else:
  print("Check system")
  exit()

print("Boundaries: 750nm,400nm: {0}, {1}".format(l1,l2))

P_visible = quad(E, l1, l2)[0]
P_tot_1 = quad(E,epsilon,1)[0]
P_tot_2 = quad(E2,epsilon,1)[0]
P_tot = P_tot_1+P_tot_2
P_tot2=quad(E,epsilon,inf)[0] #is also possible

print("Integrals: ",P_visible, P_tot, P_tot2)

print("Ratio of visible light: {0}".format(P_visible/(P_tot)))


input("Press enter to continue")


# comparison of integrators at different orders with scipy.quad

# integrate with trapezoidal rule
# 0..1 E1
# 0..1 E2
n = 16
N = sci.array([i for i in range(n,0,-1)])

x1 = sci.linspace(0,1,2**n+1)
E_1 = E(x1)
E_1[0] = 0.
E_1[-1] *= 0.5

P1_1  = sci.zeros(n)
for i in range(n):
  h = x1[2**i]-x1[0]
  P1_1[i] = sum(E_1[::2**i])*h          # trapezoidal rule: error O(h**2)

# cancel h**2 terms
P1_2 = sci.copy(P1_1)
for i in range(n-1):
  P1_2[i] = (4.*P1_1[i]-P1_1[i+1])/3.   # Simpson's rule: error O(h**4)

# cancel h**4 terms
P1_3 = sci.copy(P1_2)
for i in range(n-2):
  P1_3[i] = (16.*P1_2[i]-P1_2[i+1])/15. # error O(h**6)


E_2 = E2(x1)
E_2[0] = 0.
E_2[-1] *= 0.5

P2_1  = sci.zeros(n)
for i in range(n):
  h = x1[2**i]-x1[0]
  P2_1[i] = sum(E_2[::2**i])*h

P2_2 = sci.copy(P2_1)
for i in range(n-1):
  P2_2[i] = (4.*P2_1[i]-P2_1[i+1])/3.

P2_3 = sci.copy(P2_2)
for i in range(n-2):
  P2_3[i] = (16.*P2_2[i]-P2_2[i+1])/15.


plt.subplot(121)
plt.plot(N,abs(P1_1-P_tot_1),'rx',label='$+\mathcal{O}(h^2)$')
plt.plot(N,abs(P1_2-P_tot_1),'bx',label='$+\mathcal{O}(h^4)$')
plt.plot(N,abs(P1_3-P_tot_1),'gx',label='$+\mathcal{O}(h^6)$')
plt.semilogy()
plt.legend()
plt.xlabel('n, $2^n$ intervals')
plt.ylabel('$\Delta$, scipy.quad')

plt.subplot(122)
plt.plot(N,abs(P2_1-P_tot_2),'rx',label='$+\mathcal{O}(h^2)$')
plt.plot(N,abs(P2_2-P_tot_2),'bx',label='$+\mathcal{O}(h^4)$')
plt.plot(N,abs(P2_3-P_tot_2),'gx',label='$+\mathcal{O}(h^6)$')
plt.semilogy()
plt.legend()
plt.xlabel('n, $2^n$ intervals')
plt.ylabel('$\Delta$, scipy.quad')

plt.figure()
plt.plot(N,abs(P1_1+P2_1-P_tot2),'rx',label='$+\mathcal{O}(h^2)$')
plt.plot(N,abs(P1_2+P2_2-P_tot2),'bx',label='$+\mathcal{O}(h^4)$')
plt.plot(N,abs(P1_3+P2_3-P_tot2),'gx',label='$+\mathcal{O}(h^6)$')
plt.semilogy()
plt.legend()
plt.xlabel('n, $2^n$ intervals')
plt.ylabel('$\Delta$, scipy.quad')

plt.show()
