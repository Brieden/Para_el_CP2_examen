import scipy.optimize as opt
from scipy import sin, cos, sinh, cosh, pi
import numpy as np
import matplotlib.pyplot as plt


def A(kl, y): # from Ex.3.4, to compare results
    # y = x/l => kx = kly
    return (sin(kl) - sinh(kl)) * (cos(kl*y) - cosh(kl*y)) - \
           (cos(kl) - cosh(kl)) * (sin(kl*y) - sinh(kl*y))


def diffop(N,dx):
    num = dx**4
    D = np.eye(N)
    D = 6*D              # diagonal of 4th order centered difference operator
    for i in range(N-2): # first and second upper and lower diagonals
      D[i,i+2] = 1
      D[i,i+1] = -4
      D[i+2,i] = 1
      D[i+1,i] = -4
    D[N-1,N-2] = -4
    D[N-2,N-1] = -4
    D /= num   
    return D

# first, calculate eigenvalues and eigenvectors of the 
# finite difference operator, taking into account BC 

N=1000  # resolution

y = np.linspace(0,1,N)
dy = 1/(N-1)

D = diffop(N-4,dy) # we need to exclude the end points and penultimate points of A: A_0, A_1, A_n-1 and A_n-2

ew_num,ev_num = np.linalg.eigh(D)

# enforce BC A(0) = A(l) = 0 and A'(0) = A'(l) = 0
A_num = np.zeros((N,N-4))            
for n in range(0,N-4):
  for k in range (0,N-4):
     A_num[k+2,n] = ev_num[k,n]      # replace only A_2,...,A_(N-2) with the eigenvector, leaving A_0 = 0 and A_N = 0
  A_num[1,n] = 0.25*ev_num[0,n]      # A_1 = A_2/4 from mixed BC (Dirichlet + Neumann)      
  A_num[N-1,n] = 0.25*ev_num[N-5,n]  # A_(N-1) = A_(N-2)/4 from mixed BC (Dirichlet + Neumann) 


print("Eigenvalues obtained with finite difference operator")

for n in range(0,5):
   print(pow(ew_num[n],0.25))

print("****************************************************")

# second, to compare to Ex3.4, find eigenvalues using the
# given function A(kl,y) 

# Numerically determine eigenvalues with a bisection method
kl = np.linspace(0, 10*pi, 1000) 	# Initial conditions

ev = [0]				# list of eigenvalues (0 is one)
f = lambda b: cos(b)*cosh(b) - 1 	# objective / eigenvalue function

for x in kl:
    x1 = x+2 			# Search in interval [x, x1]
    if ( f(x)*f(x1) > 0 ):	# no sign change, continue
        continue
    root = opt.bisect(f, x, x1)
    
    if len(ev) == 0:
        ev.append(root)         
    else: 			# don't add the same eigenvalue twice
        inev = False
        for t in ev:
            if abs(t-root) < 1e-4:
                inev = True
        if not inev:
            ev.append(root)     # collect eigenvalues into a list
    if len(ev) >= 6: 		# maximum number of eigenvalues to search
        break

ev = np.array(ev)

print("Eigenvalues obtained from analytical solution by bisection")
for n in range(1,6):
   print(ev[n])
print("****************************************************")

# plot first eigenmodes, rescaled to 1
x = np.linspace(0,1, 1e5)

for n in range(0,5):
   if A_num[2,n] < 0 :
     A_num  *= -1 
   plt.plot(y,A_num[:,n]/max(A_num[:,n].max(),0.01),linewidth=3,color='black')   
   plt.plot(x,A(ev[n+1], x)/max(A(ev[n+1],x).max(),0.1),color='red')
plt.ylim(-1.1,1.1)
plt.xlabel('$x/l$')
plt.show()

exit()


