import numpy as np
from scipy.special import zetac
import math
import matplotlib.pyplot as plt

# simple quick solution

N = 7  # number of terms in sum 1/n
M = 10  # number of terms in Euler-Maclaurin series

S = 0
for n in range(1,N+1): # we need the sum up to N
   S+= 1/n                

R = 0       # the rest of the EM-series
for n in range(1,M):
   R += (-1)*pow(-1,n+1)*2*math.factorial(2*n-1)*(1+zetac(2*n))/pow(2*math.pi*N,2*n)


#print first 8 Bernoulli numbers
print("First 8 Bernoulli numbers")
for n in range(1,8):
   print(pow(-1,n+1)*2*math.factorial(2*n)*(1+zetac(2*n))/pow(2*math.pi,2*n)) 

gamma = S - math.log(N) - R - 0.5/N   

print("*************************************\n")
print("Approximation without Euler-Maclaurin")
print("Number of terms in series \t gamma")
print(N,"\t", S-math.log(N))
print("*************************************")
print("Approximation with Euler-Maclaurin")
print("Number of terms in series \t gamma")
print(N,"\t", gamma)
print("*************************************")

#exit()

# more sophisticated solution

M=10
kex=1               # f(x) = 1/x
n0=7;               # lower value
n02=n0*n0;          # square thereof
kc=kex+1;           # exponent in first derivative

bern = np.zeros(M+1)
df = np.zeros(M+1)
denom = np.zeros(M+1)
S = np.zeros(M+1)
df[1]=-1/n02;       # derivative at lower value
nc=2;
denom[1]=2;
sumi=-math.log(n0)+0.5/n0;               
for n in range(1,M):
   bern[n]=pow(-1,n+1)*2*math.factorial(2*n)*(1+zetac(2*n))/pow(2*math.pi,2*n)
   

for ni in range(1,n0):        # determine the initial value by explicit summation
    sumi=sumi+1/ni;           # remember: the sum goes to ni-1

S[1]=sumi-bern[1]*df[1]/denom[1];
for n in range(2,M+1):          # 11 nonzero Bernoulli numbers from B_2 to B_22
    df[n]=df[n-1]*kc*(kc+1)/n02;
    kc=kc+2;                  # increase by two derivatives
    denom[n]=denom[n-1]*(nc+1)*(nc+2);
    S[n]=S[n-1]-bern[n]*df[n]/denom[n];
    nc=nc+2;                  # update n for factorial


#print(bern)

#print(n0,S[10]);
sp=S-0.5772156649015328606; #error relative to exact Euler constant, Abramowitz&Stegun, Table 1.1

fig = plt.figure()
plt.semilogy(abs(sp)+1e-16,'-o'); # display error graphically
plt.xlabel("number of terms in Euler-Maclaurin")
plt.ylabel("difference to exact Euler constant")
plt.show()





