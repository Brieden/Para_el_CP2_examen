# -*- coding: utf-8 -*-

import scipy as sci 
from scipy.linalg import solve
from scipy.linalg import lu_solve
from scipy.linalg import lu_factor
from numpy.linalg import cond

def LU(A):
  if A.shape[0] != A.shape[1]:
    print ("Error, need square matrix")
    return 0
  n = A.shape[0]
  L = sci.eye(n)
  U = sci.copy(A)
  for j in range(n-1): 		# Loop over columns
    for i in range(j+1, n): 	# Loop over rows
      factor = U[i,j]/U[j,j]	# 1st element in row i equals factor*corresponding element in row j
      U[i,:] -= factor*U[j,:] 	# subtract j-th row from i-th row
      L[i,j] = factor		# store factor
  return L,U

def solveLU(L,U,b):
  n = L.shape[0]
  y = sci.zeros(n)
  x = sci.zeros(n)
  # solve L*y = b:
  for i in range(n):
    y[i] = b[i]
    for k in range(i):
      y[i] -= L[i,k]*y[k]
    #y[i] *= 1./L[i,i]		# L[i,i] = 1.0
  # solve U*x = y:
  for i in range(n-1,-1,-1):
    x[i] = y[i]
    for k in range(i+1,n):
      x[i] -= U[i,k]*x[k]
    x[i] *= 1./U[i,i]
  return y,x


# sum:
def S(k,N):
  s = 0
  for n in range(1,N+1):
    s += n**k
  return s


# polynominal:
def mat(k):
  m = sci.zeros((k+1,k+1))
  for N in range(k+1):
    for l in range(k+1):
      m[N,l] = (N+1)**(l+1)
  return m

def sums(k):
  s = sci.zeros(k+1)
  for N in range(k+1):
    s[N] = S(k,N+1)
  return s

kMax = 21

for k in range(1,kMax):
  A = mat(k)
  b = sums(k)
  #print A
  #print b
  c = solve(A,b)
  #L,U = LU(A)
  #y,c = solveLU(L,U,b)
  #sci.dot(A, c) == b
  #c = lu_solve(lu_factor(A), b)
  print ("{0} {1}".format(k,c))
  print ("Condition: ", cond(A))
  print ("Residual:" , sci.dot(A,c)-b)

