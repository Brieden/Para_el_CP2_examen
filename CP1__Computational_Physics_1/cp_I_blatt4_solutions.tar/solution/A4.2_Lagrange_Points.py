from scipy import linspace
from scipy.optimize import bisect
import numpy as np
from numpy.linalg import inv,norm
import matplotlib.pyplot as plt


def x_equation(x,y,m1,m2):
   
    xeq = m1*(x+m2)/pow(((x+m2)**2+y**2),1.5) + m2*(x-m1)/pow(((x-m1)**2+y**2),1.5)-x
    return xeq

def xy_equation(x,m1,m2):
    xeq=[0,0] 
    xeq[0] = m1*(x[0]+m2)/pow(((x[0]+m2)**2+x[1]**2),1.5) + m2*(x[0]-m1)/pow(((x[0]-m1)**2+x[1]**2),1.5)-x[0]
    xeq[1] = m1*x[1]/pow((x[0]+m2)**2+x[1]**2,1.5) + m2*x[1]/pow((x[0]-m1)**2+x[1]**2,1.5) - x[1]
    return xeq

def Jac(x,m1,m2):
    a = (x[0]+m2)**2+x[1]**2
    b = (x[0]-m1)**2+x[1]**2
    a2 = pow(a,1.5)
    b2 = pow(b,1.5)
    # derivatives of xy_equation  
    dxdf1 = m1/a2*(m2-3*(x[0]+m2)**2/a) - m2/b2*(m1+3*(x[0]-m1)**2/b) -1
    dydf1 = -3*m1*x[1]*(x[0]+m2)/(a*a2) - 3*m2*x[1]*(x[0]-m1)/(b*b2)
    dxdf2 = dydf1
    dydf2 = m1/a2*(1-3*x[1]**2/a) + m2/b2*(1-3*x[1]**3/b) - 1
    
    return np.array([[dxdf1,dydf1],[dxdf2,dydf2]])

# Find the equilibria for y=0 by bisection.
# plot x_equation for y = 0 to see how the 
#      intervals for the bisection should be set

#m1=0.5    #test case
#m2=1-m1

#m1=0.4    #test case
#m2=1-m1

m1=3e-6  #Earth-Sun system
m2=1-m1
x = linspace(-2,2,100)

fig = plt.figure()
plt.plot(x,x_equation(x,0,m1,m2))
axes = plt.gca()
axes.axhline(0,color='black')
axes.set_ylim(-20,20)
plt.savefig('A4.2_Lagrange_Points1.png')


# Now find the equilibria
print('*************************************')
print("Finding equilibria for y = 0")
 # scipy in-built function, defaults are 
 # tolerance = 4.4408920985006262e-16, maxiter = 100 
x0 = bisect(x_equation,-2,-0.75,args=(0,m1,m2))
print('x0 = ',x0)
x1 = bisect(x_equation,-0.00001,4e-6,args=(0,m1,m2),maxiter=2000) 
print('x1 = ',x1)
x2 = bisect(x_equation,0.75,2,args=(0,m1,m2)) 
print('x2 = ',x2)
print('*************************************')

# Find the equilibria for y!=0 with a 2D Newton search.
print("Finding equilibria for y != 0")
# find equilibria for y != 0
m1=3e-6
m2=1-m1
guess = [-0.5,0.8]
tol = 2e-11
maxiter = 100000000
n=0
diff = 1
z0 = guess
z=guess
while (n<maxiter and diff > tol):
    #print(z,n)
    z = z0 - np.dot(inv(Jac(z0,m1,m2)),xy_equation(z0,m1,m2))  
    diff = norm(z-z0)
    z0 = z
    n+=1

print("equilibrium " ," number of iterations")
print(z,n)
print('*************************************')

# sanity check: is the point we found an equilibrium? 
print('Checking equilibrium')
print('f(x3) = ', xy_equation(z,m1,m2))

exit()
