# -*- coding: utf-8 -*-
# Prandtl-von Karman law

# if you have problems running this script, remove the "$" from the "label"-commands. 
# They only work in tex-mode.

import scipy as sci
import pylab as plt
import numpy as np

A = 0.88
B = -0.81

# Laminar factor:
def fLaminar(Re):
  return 64./Re

# bisection algorithm:
def bisection(f,xa,xb,arg):
  n = 0
  low = f(xa,arg)
  high = f(xb,arg)
  if ((low*high) > 0):
    print ("Apparently no sign change")
    return 0
  while (n < 52):
    n += 1
    xTrial = (xa+xb)/2.
    fTrial = f(xTrial,arg)
    if (fTrial*low < 0):
      high = fTrial
      xb = xTrial
    else:
      low = fTrial
      xa = xTrial
  return [xa,xb],[low,high]


# objective function:
def objective(x,Re):
  return A*sci.log(Re*sci.sqrt(x))+B - 1./sci.sqrt(x)

#
# approach 1: zero-value problem g(f)
#

ReList = sci.logspace(2,8,70)
f=[]

for Re in ReList:
  [[xa,xb],[low,high]]= bisection(objective,1e-8,1,Re)
  f.append(xa)

plt.figure()
plt.plot(ReList,f,'rx',label='turbulent')
plt.plot(ReList,fLaminar(ReList),'bx',label='laminar')
plt.loglog()

plt.xlabel(r'$Re$')
plt.ylabel(r'$f(Re)$')
plt.legend()
plt.title(r"Approach 1: treat as zero-value problem")

#plt.show()

# approach 2: iterations (Banach fixed point theorem)
# two possible functions 
def iter1(x,Re):  #g_1
  return 1./(A*sci.log(Re*sci.sqrt(x))+B)**2
  
def iter2(x,Re):  #g_2
  return (sci.exp((1./sci.sqrt(x)-B)/A)/Re)**2
# their respective derivatives
def der1(x,Re):
  return -A/(x*(A*sci.log(Re*sci.sqrt(x))+B)**2)

def der2(x,Re):
  return -sci.exp(2.*(1/sci.sqrt(x)-B)/A)/(A*Re**2*x**1.5)

# show derivatives for a value of Re 
Re = 1e6
fList = sci.linspace(0.01,0.025,100)
#fList = sci.linspace(0.00001,1,100)
plt.figure()
plt.plot(fList,abs(der1(fList,Re)),'rx', label = '$g_1 = (A \ln(Re\sqrt{f})+B)^2$')
plt.plot(fList,abs(der2(fList,Re)),'bx', label = '$g_2 = (e^{1/(A\sqrt{f}) - B/A}/Re)^2$')
plt.ylabel(r'$|g\prime (f))|$')
plt.xlabel(r'$f$')
plt.ylim(0,3)
plt.title(r'Derivatives of functions in Banach iteration at $Re=10^6$')
plt.legend()
#plt.show()

# use Re = 1000 and f=64/Re as starting point (transitional Re is Re = 2040)
ReList_b=sci.logspace(3,8,70)
f_banach=[]

for Re in ReList_b:
  fb=64/Re
  ic=0
  df=1 
  while (df>1e-3 and (ic < 1000)):
    fb=iter1(fb,Re)
    ic = ic+1 
  f_banach.append(fb)      

plt.figure()
plt.plot(ReList_b,f_banach,'rx',label='turbulent')
plt.plot(ReList,fLaminar(ReList),'bx',label='laminar')
plt.loglog()
plt.xlabel(r'$Re$')
plt.ylabel(r'$f(Re)$')
plt.legend()
plt.title(r"Approach 2: Banach iterations")

# approach 3: solve for Re

# Re as dunction of f:
def ReFunc(f):
  return sci.exp((1./sci.sqrt(f)-B)/A)/sci.sqrt(f)

# approximate range of f:
fRange = sci.logspace(-16,0,1000)
np.seterr(all='ignore') # ignore overflow warnings due to values < machine epsilon in fRange
                         
plt.figure()
plt.plot(ReFunc(fRange),fRange,'rx',label='turbulent')
plt.plot(ReList,fLaminar(ReList),'bx',label='laminar')
plt.loglog()
# limit interval on the x-axis
plt.xlim(1e2,1e8)

plt.xlabel(r'$Re$')
plt.ylabel(r'$f(Re)$')
plt.legend()
plt.title(r"Approach 3: solve for $Re$")

plt.show()

