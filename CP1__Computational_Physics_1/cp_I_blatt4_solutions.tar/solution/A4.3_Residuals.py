# -*- coding: utf-8 -*-

import scipy as sci
from scipy.linalg import lu_solve, lu_factor
from scipy.linalg import norm,inv, eigvals, svd
from numpy.linalg import cond

A = sci.array( [[1.2969, 0.8648],
            [0.2161, 0.1441]] )
x = sci.array( [0.9911, -0.4870] )
b = sci.array( [0.8642, 0.1440] )

# Calculate residual
residual = abs(sci.dot(A,x) - b)
print("Residual:")
print("%e %e" %(residual[0], residual[1]))

# Print exact result from lu decomposition
print("Exact solution from scipy.linalg.lu_solve:")
print(lu_solve(lu_factor(A), b))
# Print the condition of A
print("Condition of A:")
print(cond(A))
print(norm(A)*norm(inv(A)))	# Frobenius norm ( sqrt( \sum a_ij**2 )
print(norm(A,2)/norm(A,-2))	# 2-norm ( largest / smallest singular value, singular value dec.) 
s = svd(A,compute_uv=False)
print(s.max()/s.min())		#explicitly
print(sci.sqrt( abs(eigvals(A.transpose().dot(A))).max() * abs(eigvals(inv(A).transpose().dot(inv(A)))).max() )) # using sig_max = sqrt(max(eigval(A^t*A)))
print(A.max()*inv(A).max())


input("Press enter to continue")


# Implement LU-decomposition for demonstration purpose
# Dangerous: no pivotation used
def LU(A):
  if A.shape[0] != A.shape[1]:
    print ("Error, need square matrix")
    return 0
  n = A.shape[0]
  L = sci.eye(n)
  U = sci.copy(A)
  for j in range(n-1): 		# Loop over columns
    for i in range(j+1, n): 	# Loop over rows
      factor = U[i,j]/U[j,j]	# 1st element in row i equals factor*corresponding element in row j
      U[i,:] -= factor*U[j,:] 	# subtract j-th row from i-th row
      L[i,j] = factor		# store factor
  return L,U

def solveLU(L,U,b):
  n = L.shape[0]
  y = sci.zeros(n)
  x = sci.zeros(n)
  # solve L*y = b:
  for i in range(n):
    y[i] = b[i]
    for k in range(i):
      y[i] -= L[i,k]*y[k]
    #y[i] *= 1./L[i,i]		# L[i,i] = 1.0
  # solve U*x = y:
  for i in range(n-1,-1,-1):
    x[i] = y[i]
    for k in range(i+1,n):
      x[i] -= U[i,k]*x[k]
    x[i] *= 1./U[i,i]
  return y,x


L,U = LU(A)
print("L\n", L)
print("U\n", U)
y,x = solveLU(L,U,b)
print("x\n", x)
  
  
A = sci.rand(5,5)*1e2

L,U = LU(A)

print("\nLU-decomposition")
print("A\n", A)
print("U\n", U)
print("L\n", L)
print("LU = A\n", abs(sci.dot(L,U) - A) < 1e-10)
print("Condition of A:")
print(cond(A))
print(norm(A)*norm(inv(A)))	# Frobenius norm ( sqrt( \sum a_ij**2 )
print(norm(A,2)/norm(A,-2))	# 2-norm ( largest / smallest singular value, singular value dec.) 
s = svd(A,compute_uv=False)
print(s.max()/s.min())		#explicitly
print(sci.sqrt( abs(eigvals(A.transpose().dot(A))).max() * abs(eigvals(inv(A).transpose().dot(inv(A)))).max() )) # using sig_max = sqrt(max(eigval(A^t*A)))
print(A.max()*inv(A).max())


  
