# -*- coding: utf-8 -*-

import scipy as sci
import numpy as np
import pylab as plt

def sumUp(N):
  s = 0.
  for i in range(1,N+1):
  # iterating through a numpy array is *much slower* 
  #for i in (np.arange(1,N+1,1)):
    s  += (2*i+1)/(i**2*(i+1.)**2)
  return s

def sumDown(N):
  s = 0.
  for i in range(N,0,-1):
    s  += (2*i+1)/(i**2*(i+1.)**2)
  return s

def sumAn(N):
  return 1. - 1./((N+1.)**2)


NList = sci.linspace(10,1000000,20)

s1 = []
s2 = []
s3 = []

# calculate sums:
for N in NList:
  s1.append(sumUp(int(N)))
  s2.append(sumDown(int(N)))
  s3.append(sumAn(int(N)))
  
s1 = sci.array(s1)
s2 = sci.array(s2)
s3 = sci.array(s3)

# plot the difference to the analytical value 
plt.plot(NList,s1-s3,label = 'up')
plt.plot(NList,s2-s3,label = 'down')

plt.xlabel("N")
plt.ylabel(r"$\Delta$")

plt.legend()

plt.savefig("A2.2_delta.pdf")


# calculate how may terms you need to get to the 
# limit with a given accuracy
M=1
while ((1-sumUp(M)) > 1e-5):
      sumUp(M)
      M+=1 

print(M)

# show that there is a difference between upward and 
# downward summation for a set number of terms
print(sumUp(10000))
print(sumDown(10000))


print("N = {0}".format(NList[-1]))
print("Analytical result: {0}".format(s3[-1]))
print("Summing up from below: {0}".format(s1[-1]))
print("Summing up from above: {0}".format(s2[-1]))
