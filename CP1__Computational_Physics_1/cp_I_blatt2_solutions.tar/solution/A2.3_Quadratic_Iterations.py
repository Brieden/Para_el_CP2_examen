# -*- coding: utf-8 -*-

import scipy as sci
import pylab as plt


def phiToX(phi):
    # return: phi(x)
    return (sci.sin(sci.pi*.5*phi))**2


def phi_n(phi):
  return 1-2*abs(phi-.5)

def x_n(x):
  return 4*x*(1-x)


def x_N(N,x0):
  x = sci.zeros(N+1)
  x[0] = x0
  for i in range(N):
    x[i+1] = x_n(x[i])
  return x

def phi_N(N,phi0):
  phi = sci.zeros(N+1)
  phi[0] = phi0
  for i in range(N):
    phi[i+1] = phi_n(phi[i])
  return phi


# Define initial values
phi0 = 1./sci.sqrt(2)
phi0 = sci.rand()
phi0 = 0.4		# periodic orbit
#phi0 = 0.375		# preimage of 0
#phi0 = sp.log(2)
x0 = phiToX(phi0)
print (x0, phi0)


# Compute arrays
N = 100 # number of iterations
x = x_N(N, x0)
phi_temp = phi_N(N, phi0)
phi = phiToX(phi_N(N, phi0))

print (phi_temp)


# plot both maps
plt.figure()
plt.subplot(211)
plt.plot(sci.linspace(0,1,101),x_n(sci.linspace(0,1,101)),'b')
plt.plot(sci.linspace(0,1,101),sci.linspace(0,1,101),'0.5')
plt.xlabel('$x_n$')
plt.ylabel('$x_{n+1}$')
plt.gca().set_aspect(1)

plt.subplot(212)
plt.plot(sci.linspace(0,1,101),phi_n(sci.linspace(0,1,101)),'g')
plt.plot(sci.linspace(0,1,101),sci.linspace(0,1,101),'0.5')
plt.xlabel('$\phi_n$')
plt.ylabel('$\phi_{n+1}$')
plt.gca().set_aspect(1)


# Plot the two maps, x_n vs. x_n+1
plt.figure()
plt.subplot(211)
plt.plot(x,'b',label='x_n')
plt.plot(phi, 'g', label="x(phi_n)")
plt.xlabel('$n$')
plt.xlabel('$x(n)$')
plt.legend()

# Plot difference between the two maps
plt.subplot(212)
plt.semilogy(abs(x-phi))
plt.xlabel('$n$')
plt.ylabel('$|x-\phi|$')

plt.show()
