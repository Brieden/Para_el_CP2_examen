# -*- coding: utf-8 -*-

import scipy as sci
import time

def f1(x):
  return sci.tanh(x)

def f2(x):
  return sci.sinh(x)/sci.cosh(x)

def f3(x):
  return (sci.exp(2*x)-1)/(sci.exp(2*x)+1)

def f4(x):
  y = sci.exp(2*x)
  return (y-1)/(y+1)

def f5(x):
  return x - x*x*x/3. + 2.*x*x*x*x*x/15.-17.*x*x*x*x*x*x*x/315

def f6(x):
  return x - x**3/3. + 2.*x**5/15.-17.*x**7/315

def f7(x):
  return 2.*x


def meantime(f,N):
    t = 0
    for i in range(1,N):
     tstart = time.clock()
     f(x)
     tend = time.clock()
     t += (tend-tstart)
    return t/N    


x = sci.linspace(0,1,100000)

t0 = time.clock()

f1(x)
#for i in x:
  #f1(i)

t1 = time.clock()

f2(x)
#for i in x:
  #f2(i)

t2 = time.clock()

f3(x)
#for i in x:
  #f3(i)

t3 = time.clock()

f4(x)
#for i in x:
  #f4(i)

t4 = time.clock()

f5(x)
#for i in x:
#  f5(i)

t5 = time.clock()

f6(x)
#for i in x:
#  f6(i)

t6 = time.clock()

f7(x)
#for i in x:
#  f7(i)

t7 = time.clock()

#mean over 10 evaluations
t1_mean = meantime(f1,10)
t2_mean = meantime(f2,10)
t3_mean = meantime(f3,10)
t4_mean = meantime(f4,10)
t5_mean = meantime(f5,10)
t6_mean = meantime(f6,10)
t7_mean = meantime(f7,10)

print("\nSingle evaluations:")

print ("Runtime for function 1: tanh(x):                     {0}".format(t1-t0))
print ("Runtime for function 2: sinh(x)/cosh(x):             {0}".format(t2-t1))
print ("Runtime for function 3: (e**{{2x}}-1)/(e**{{2x}}+1):     {0}".format(t3-t2))
print ("Runtime for function 4: w. y = e**{{2x}}:              {0}".format(t4-t3))
print ("Runtime for function 5: expansion1:                  {0}".format(t5-t4))
print ("Runtime for function 6: expansion2:                  {0}".format(t6-t5))
print ("Runtime for function 7: 2.*x:                        {0}".format(t7-t6))
print ("\n")

#exit()

print("*****************************************************************************")

print("\nMean over 10 evaluations:")

print ("Runtime for function 1: tanh(x):                     {0}".format(t1_mean))
print ("Runtime for function 2: sinh(x)/cosh(x):             {0}".format(t2_mean))
print ("Runtime for function 3: (e**{{2x}}-1)/(e**{{2x}}+1):     {0}".format(t3_mean))
print ("Runtime for function 4: w. y = e**{{2x}}:              {0}".format(t4_mean))
print ("Runtime for function 5: expansion1:                  {0}".format(t5_mean))
print ("Runtime for function 6: expansion2:                  {0}".format(t6_mean))
print ("Runtime for function 7: 2.*x:                        {0}".format(t7_mean))

exit()
