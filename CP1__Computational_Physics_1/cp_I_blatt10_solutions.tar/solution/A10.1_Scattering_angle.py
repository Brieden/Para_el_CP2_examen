import scipy as sci
from scipy.integrate import quad
from scipy.optimize import bisect
from math import pi
import pylab as plt

epsilon = 1e-8
# Employ subsitution r = 1/u to avoid infinity

# The denominator in the integral for the scattering angle
def denominator(E, V, b, u):
    return sci.sqrt(1.-b*b*u*u - V(u)/E)

#The turning point r+ = 1/u+
def u_plus(E,V,b):
    root = lambda u: 1. - b*b*u*u - V(u)/E
    ds = 0.01
    u0 = epsilon
    u1 = 0.1
    while (root(u0)*root(u1) > 0):
      u0 = u1 
      u1 += ds
    return bisect(root,u0,u1)

    
#transformed function, u = u+ -s**2
# integration bounds: 0 .. sqrt(u+)
def transformed(E,V,b,up,s):
    return b*2.*s/sci.sqrt(1-b**2*(up-s**2)**2-V(up-s**2)/E)


# The scattering angle for a single impact parameter
def chi(E, V, b):
    up = u_plus(E,V,b)
    #print(b, 1./up)
    #f = lambda u: b/denominator(E, V, b, u)      # use substitution r=1/u
    #return sci.pi - 2 * quad(f, epsilon, up-epsilon)[0]
    f = lambda s: transformed(E,V,b,up,s)         # use substitution u = u+ -s**2 ->  r= 1/(1/r+ -s**2), i.e s=sqrt(1/r+ - 1/r)
    return sci.pi - 2 * quad(f, epsilon, sci.sqrt(up))[0]
    
    
# Calculate scattering angle for an array b of impact parameters
def CalcScatteringAngle(E, V, b):
    # E: energy
    # V: potential function
    # b: impact parameter, array
    l = len(b)
    chi_ = sci.zeros(l)
    for i in range(l):
        chi_[i] = chi(E, V, b[i])
    return chi_

# Find potentially harmful points in the denominator function
def PlotDenominator(E, V, b):
    plt.figure()
    for B in b:
        u = sci.linspace(epsilon,u_plus(E,V,B)-epsilon)
        plt.semilogy(u, 1./denominator(E, V, B, u))
    plt.xlabel('$u = 1/r$')
    plt.ylabel('transformed integrand')

# plot transformed function
def PlotTransformed(E,V,b):
  plt.figure()
  for B in b:
    up = u_plus(E,V,B)
    s = sci.linspace(0,sci.sqrt(up),100)
    plt.semilogy(s, transformed(E, V, B,up, s))
    #plt.plot(s, transformed(E, V, B,up, s))
    plt.xlabel('$s=\sqrt{1/r^+ - 1/r}$')
    plt.ylabel('transformed integrand')

# Plot b vs. chi
def PlotScatteringAngle(E, V):
    b = sci.linspace(0.01, 5, 100)
    plt.figure()
    for e in E:
      chi_ = CalcScatteringAngle(e, V, b) #% (2*sp.pi)
      plt.plot(b, chi_/pi,label='E={0}'.format(e))
    plt.xlabel('$b$')
    plt.ylabel('$\chi/\pi$')
    plt.legend()
    

V_0 = lambda u: 0			# no potential
V_rep = lambda u: u*u 			# The repulsive potential
V_att = lambda u: -sci.exp(-1./u) 	# The attractive potential
V_LJ = lambda u: u**12 - 2*u**6. 	# Lennard Jones potential
V_L = lambda u: b*b*u*u			# angular momentum

#plot potentials
#b = 0.1
#r = sci.linspace(0.1,10,100)
#plt.title('$b = 0.1$')
#plt.plot(r,V_rep(1/r)+V_L(1/r))
#plt.plot(r,V_att(1/r)+V_L(1/r))
#plt.plot(r,V_LJ(1/r)+V_L(1/r))
#plt.xlabel('$r$')
#plt.ylabel('$V(r)$')
#plt.ylim(-10,10)

PlotTransformed(2.,V_rep,[5])
PlotDenominator(2., V_rep, [5.])

PlotScatteringAngle([10.,5,2.5,1.25], V_0)
PlotScatteringAngle([10.,5,2.5,1.25], V_att)
PlotScatteringAngle([10.,5,2.5,1.25], V_rep)
PlotScatteringAngle([10.,5,2.5,1.25], V_LJ)
plt.show()
