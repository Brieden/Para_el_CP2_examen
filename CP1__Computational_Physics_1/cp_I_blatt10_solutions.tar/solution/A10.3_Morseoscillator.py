import scipy as sci
import pylab as plt

from scipy.integrate import odeint

def V(x):
  return sci.exp(-2*x)-2*sci.exp(-x)

# \ddot x = - \grad V
# transform 2nd order ODE into 2D system of first-order ODEs 
# and solve that system with odeint:
# x_tt = y_t    -> x=x[0], y=x[1]
# y_t = -\gradV 
def f(x,t):
  return sci.array([x[1],2.*(sci.exp(-2.*x[0])-sci.exp(-x[0]))])

# plot potential:

x = sci.linspace(-10,10,100)
plt.plot(x,V(x))
ax=plt.gca()
ax.axhline(0,color = 'black')
plt.xlabel('$x$')
plt.ylabel('$V(x)$')
plt.ylim(-1,3)

# bounded motion: E < 0

E0 = -.1

# initial conditions:
x0 = 0.
v0 = sci.sqrt(2.*(E0-V(x0)))

#T = 10
#h = 1e-3
#x,t = integrate(f,sci.array([x0,v0]),0,T,h,rk4)

t = sci.linspace(0,100,1000)
x,info = odeint(f,sci.array([x0,v0]),t,full_output=True)
E = .5*x[:,1]*x[:,1] + V(x[:,0])

plt.figure()
plt.plot(t,E,label='E(t)')
plt.plot(t,x[:,0],label='x(t)')
plt.plot(t,x[:,1],label='v(t)')
plt.xlabel("$t$")
plt.ylabel("$E,x,v$")
plt.legend()


plt.figure()
plt.title("Phase space")
plt.plot(x[:,0],x[:,1])
plt.xlabel("$x$")
plt.ylabel("$v$")

plt.figure()
plt.title("Energy conservation")
plt.plot(t, abs(E-E0))
plt.semilogy()
plt.ylim(1e-9)
plt.xlabel("$t$")
plt.ylabel("$\Delta E$")

plt.figure()
plt.title("Stepsize control")
plt.plot(t,x[:,0]/x[:,0].max(),label='$x/\max(x)$')
plt.plot(info['tcur'],info['hu'],label='$h$')
plt.xlabel("$t$")
plt.ylabel("$x/\max(x) \quad | \quad h$")
plt.legend()

plt.show()
