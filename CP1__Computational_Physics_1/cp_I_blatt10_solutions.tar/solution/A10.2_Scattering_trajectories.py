import scipy as sci
import numpy as np
from scipy.integrate import odeint
from math import pi
import pylab as plt

T = 10
E = 2.
m = 1.

# derivatives of the potential
def dVdx(x,y):
    r2 = (x*x + y*y)
    return 12.*x*( pow(r2,-4) - pow(r2, -7))

def dVdy(x,y):
    r2 = (x*x + y*y)
    return 12.*y*( pow(r2,-4) - pow(r2, -7))

# Lenard-Jones potential
def V(x0):
    x = x0[0]
    y = x0[1]
    r2 = x*x + y*y
    return pow(r2,-6) - 2*pow(r2, -3)

# Differential equation
# transform 2D 2nd order ODE system into 4D system of first-order ODEs 
# and solve that system with odeint:
# x_tt = x_t,
# y_tt = y_t,
# x_t = -dVdx,
# y_t = -dVdy,
# Therefore, set the input vector to be used in odeint as x = [x, y, dot x, dot y]
def LJ(x, t):
    return [x[2],
            x[3],
            -dVdx(x[0], x[1])/m,
            -dVdy(x[0], x[1])/m]


# Plot a single trajectory
def PlotTrajectory(b, E0, fignum=0):
    pos = [-4, b]
    x0 = [pos[0], pos[1], sci.sqrt(2/m*(E0 - V(pos))), 0]  # initial condition x0 = [x_0,y_0,vx,vy]: velocity in y-direction vy = 0
    t = sci.linspace(0, T, 500)
    x = odeint(LJ, x0, t)
    
    plt.figure(fignum)
    plt.title("A bunch of trajectories")
    plt.plot(x[:,0], x[:,1], 'b')
    plt.plot(0, 0, 'o')
    plt.xlim(-4, 4)
    plt.ylim(-2,4)

# Plot a bunch of trajectories for different impact parameters
for b in sci.linspace(0.1, 2, 10): 
    PlotTrajectory(b, E)
plt.xlabel('$x$')
plt.ylabel('$y$')

     
# Energy
# x = [x, y, dot x, dot y](t)
def Energy(x):
    if len(x.shape) == 1:			# Case single vector
        return V(x) + .5*m*(x[2]**2 + x[3]**2)
    elif len(x.shape) == 2:			# Case several vectors ( result from odeint )
        r = x[:,0]**2 + x[:,1]**2
        return  pow(r,-6) - 2*pow(r, -3) + .5*m*(x[:,2]**2 + x[:,3]**2)

# Angular momentum
def L(x):
  # L = r x p
  if len(x.shape) == 1:
    return m*sci.cross(x[0:2],x[2:4])
  elif len(x.shape) == 2:
    return m*sci.cross(x[:,0:2],x[:,2:4])
    
# Diagnostics: set up a trajectory: impact parameter, initial condition, time
b = 2
pos = [-4, b]
print(V(pos))
x0 = sci.array([pos[0], pos[1], sci.sqrt(2/m*(E - V(pos))), 0])
t = sci.linspace(0, T, 500)     

# 1: Behaviour of time step along a trajectory: 
x,info = odeint(LJ, x0, t,full_output=True)
plt.figure()
plt.title("Step size")
# plot dt vs t
plt.plot(info['tcur'],info['hu'],label='$h$') # see documentation of scipy.integrate.odeint
# plot distance of moving particle from scatterer located at (x=0,y=0), rescale for readability of figure
plt.plot(t, 0.01*(sci.sqrt(x[:,0]**2 + x[:,1]**2)),label='$|(x(t),y(t))|/100$')
plt.xlabel('$t$')
plt.ylabel('$h \quad | \quad |(x,y)|/100$')
plt.xlim(0,10)
plt.legend(loc=2)

# 2: Test energy conservation (x0 from above)
print("Energy = {0}".format(Energy(x0)))
E0 = Energy(x0)
plt.figure()
plt.title("Energy conservation")
plt.semilogy(t, abs(Energy(x)-E0))
plt.xlabel('$t$')
plt.ylabel('$\Delta E$')

# 3: Test angular momentum conservation (x0 from above):
print("Angular momentum: {0}".format(L(x0)))
L0 = L(x0)
plt.figure()
plt.title("Angular momentum conservation")
plt.semilogy(t, abs(L(x)-L0))
plt.xlabel('$t$')
plt.ylabel('$\Delta L$')

# Calculate scattering angle 
def ScatteringAngle(b, E0):
    pos = [-4, b]
    x0 = [pos[0], pos[1], sci.sqrt(2*(E0 - V(pos))), 0]
    t = sci.linspace(0, 10, 100)
    x = odeint(LJ, x0, t)
    a = x[-1,3]/x[-1,2]		# Slope at last timestep ( = direction of movement )
    chi = sci.arctan(a)
    #print b,x[-1,2], x[-1,3], a, chi
    if x[-1,2]  < 0 and x[-1,3] > 0:		# v_x < 0
      chi += sci.pi
    if x[-1,2]<0 and x[-1,3]<0:			# v_x < 0 & v_y < 0
      chi -= sci.pi
    return chi

# Plot Scattering angle as a function of impact parameter
blist = sci.linspace(0.1, 5, 50)
chilist = sci.zeros(len(blist))
for i in range(len(blist)):
    b = blist[i]
    chilist[i] = ScatteringAngle(b, E)

plt.figure()
plt.title("Scattering angle vs. impact parameter")
plt.xlabel('$b$')
plt.ylabel('$\chi(b)/\pi$')
plt.plot(blist, chilist/pi)
plt.show()

