import matplotlib.pyplot as plt
import numpy as np
from scipy import linalg,sparse
from scipy.sparse.linalg import inv
from scipy.sparse import csc_matrix

N = 10 # set the dimension of the problem

b = np.zeros(N) # Vector in equation Ax=b, b= (1,0,...,0)
b[0] = 1

# L and U analytically obtained from induction
L = np.eye(N) # already sets the diagonal of L
U = np.eye(N)
U[0,0] = 2
for i in range(N-1):
  U[i+1,i+1] = (i+3)/(i+2)  # diagonal of U
  U[i,i+1] = -1             # upper diagonal of U
  L[i+1,i] = -(i+1)/(i+2)   # lower diagonal of L


# solve Ly = b
#y = linalg.solve(L,b) 
y = np.dot(linalg.inv(L),b) #alternative

# solve Uy = x
#x = linalg.solve(U,y)
x = np.dot(linalg.inv(U),y)

print('\n result from LU-decomposition done analytically:\n',x)

# do the LU-decomposition numerically
U1=np.eye(N)       
L1=np.eye(N)       # diagonal of L set already
diagA = np.ones(N)
diagA = 2*diagA
UdiagA = np.ones(N) # we need only N-1 here, but we keep an element in the last entry to use later for sparse matrix class  
UdiagA = -UdiagA

U1[0,0]=2
for i in range(N-1):
  L1[i+1,i] = UdiagA[i]/U1[i,i] 
  U1[i+1,i+1] = L1[i+1,i] + diagA[i] 
  U1[i,i+1] = UdiagA[i]

# solve Ly = b
y = np.dot(linalg.inv(L1),b)

# solve Uy = x
x = np.dot(linalg.inv(U1),y)

print('\n result from LU-decomposition numerically, own implementation:\n',x)


# compare result to python in-built-function
A = np.eye(N)

A[0,0] = 2
for i in range(N-1):
 A[i+1,i+1] = 2
 A[i,i+1] = A[i+1,i] = -1

LU = linalg.lu_factor(A)
x = linalg.lu_solve(LU,b)

print('\n result from LU-decomposition numerically, python3 implementation:\n',x)

print('\n *************** Use the sparse matrix class *****************')
# better memory usage: store only the diagonals  
U2=np.zeros(N)   # diagonal of U
L2=np.zeros(N)   # lower diagonal of L. We need only N-1 here, but we keep an element in the last entry to use later for sparse matrix class  
diagL = np.ones(N)

U2[0]=2
for i in range(N-1):
  L2[i] = UdiagA[i]/U2[i] 
  U2[i+1] = L2[i] + diagA[i] 

# set up tridiagional matrices using the sparse class, 
# see e.g. http://www.scipy-lectures.org/advanced/scipy_sparse/dia_matrix.html#examples
# and      https://docs.scipy.org/doc/scipy/reference/sparse.linalg.html

# create arrays holding the necessary data
matrix_U = np.array([U2,UdiagA])
matrix_L = np.array([diagL,L2])

#information on what diagonal the 1D-array is sitting 0: actual diagonal, > 0 upper diagonals, < 0 lower diagonals
offsetsU = [0,1] 
offsetsL = [0,-1]

#create the sparse matrices from the arrays 
matrix_U = sparse.dia_matrix((matrix_U,offsetsU),shape=(N,N))
matrix_L = sparse.dia_matrix((matrix_L,offsetsL),shape=(N,N))
print('\n sparse storage for U:\n',matrix_U)
print('\n sparse storage for L:\n',matrix_L)

matrix_U = csc_matrix(matrix_U) # compressed format to get better performance for matrix operations
matrix_L = csc_matrix(matrix_L)


# solve Ly = b
y = inv(matrix_L)*b

# solve Uy = x
x = inv(matrix_U)*y

print('\n result from LU-decomposition numerically, sparse class:\n',x)
exit()
