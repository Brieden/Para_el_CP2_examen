N = 3

import pylab as plt
import scipy as sci
import scipy.linalg as linalg

from scipy import sqrt


def dV(x, n):
    # grad(V) for particle n
    # external potential:
    res = sci.copy(x[n])
    # vortex-vortex interaction:
    for i in range(x.shape[0]):
        if i != n:
            v = x[n] - x[i]
            # each entry of x and therefore v is a 2D array: x[i] = (x_i,y_i) and v = (v_1,v_2),  
            # here we sum v_1**2 + v_2**2 = |v|**2
            d = sqrt(sum(v**2))
            res -= v / d**2  # d/dx[n] (0.5 x[n]^2 -log(|x[n]-x[i]|)) = x[n]-(x[n]-x[i])/|x[n]-x[i]|^2 
    return res

def grad(x,sym=True):
   #grad(V) for all particles
   res = sci.zeros(x.shape)
   for i in range(x.shape[0]):
     res[i] = dV(x, i)
   if sym:
    res[0,1] = 0
   return res

def J(x):
  # Jacobian (2N-1)x(2N-1)
  jac = sci.eye(2*N)
  jac = -jac
  for i in range(N):
    for j in range(i):
      r = x[i]-x[j]
      d = sqrt(sum(r**2))
      jxx = 1./d**2 - 2.*r[0]**2/d**4  # x[i] = (x_i,y_i), so r[0] = x_i-x_j  
      jyy = 1./d**2 - 2.*r[1]**2/d**4  # x[i] = (x_i,y_i), s0 r[1] = y_i-y_j  
      jxy =        - 2.*r[0]*r[1]/d**4
      
      jac[2*i,2*i]       += jxx		# d^2V/dxidxi
      jac[2*i+1,2*i+1]   += jyy		# d^2V/dyidyi
      jac[2*i,2*i+1]	 += jxy		# d^2V/dxidyi
      jac[2*i+1,2*i]	 += jxy		# d^2V/dyidxi
      jac[2*i,2*j]	 -= jxx		# d^2V/dxidxj
      jac[2*i,2*j+1]	 -= jxy      	# d^2V/dxidyj
      jac[2*i+1,2*j]	 -= jxy	      	# d^2V/dyidxj
      jac[2*i+1,2*j+1]   -= jyy		# d^2V/dyjdyj
      jac[2*j,2*j]       += jxx		# d^2V/dxjdxj
      jac[2*j+1,2*j+1]   += jyy		# d^2V/dyjdyj
      jac[2*j,2*j+1]	 += jxy		# d^2V/dxidyi
      jac[2*j+1,2*j]	 += jxy		# d^2V/dyidxi
      jac[2*j,2*i]	 -= jxx		# d^2V/dxidxj
      jac[2*j,2*i+1]	 -= jxy      	# d^2V/dxidyj
      jac[2*j+1,2*i]	 -= jxy	      	# d^2V/dyidxj
      jac[2*j+1,2*i+1]   -= jyy  	# d^2V/dyidyj
  return jac


def newton(x,sym=True,delta = 1.,eps =  1e-8):
  # sym: use symmetry-reduced equations
  # delta: reduced stepsize
  # eps: convergence criterion
  j = J(x)
  if sym:
    j = sci.delete(j,1,0)
    j = sci.delete(j,1,1)
  f = sci.copy(x)
  if sym:
    f = sci.delete(-grad(x,sym),1)
  else:
    f = -grad(x,sym).reshape(2*N)
  dx = sci.linalg.solve(j,f)
  if sym:
    dx = sci.insert(dx,1,0)
  dx = dx.reshape(N,2)
  x -= delta*dx
  if sci.any(abs(grad(x,sym))>eps):
    return False
  return True




# Set some random initial positions
sci.random.seed(0)
x = sci.randn(N, 2)
x[0,1] = 0 # First particle on x-axis to avoid continuous symmetry


# Approximate equilibrium with a gradient method
l = 0.1 # lambda for gradient method
nmax = 1000 # maximum number of iterations
converged = False
i = 0
while i < nmax and converged == False:
    i += 1
    converged = True
    d = grad(x,True)
    if sci.any(abs(d) > 1e-2):
            converged = False
    x -= l*d   

print("\nNumber of gradient-iterations: {0}".format(i))
print(grad(x,True))

# Better convergence with some Newton steps
x[0,1] = 0		# reassure symmetry (plain newton rips this apart)
converged = False
i = 0
while (i < nmax and converged == False):
  i += 1
  converged = newton(x,sym = True,delta=.1)

# check results:
print("\nNumber of Newton-iterations: {0}".format(i))
print(grad(x))

# stability of result
j = J(x)
ew,ev = sci.linalg.eig(j)
print("\nEigenvalues:")
print(ew)

print("\nEigenvalues and eigenvectors:")
l=0
for eigen in ev:
    print(l,ew[l], ev[:,l])    # print eigenvalue and eigenvector
    l+=1

#plot all eigenvalues and eigenvectors:
for i in range(len(ew)):
  fig=plt.figure()
  plt.plot(x[:,0], x[:,1], 'o')
  plt.gca().set_aspect(1)
  plt.xlabel('x')
  plt.ylabel('y')
  plt.xlim(-6,6)
  plt.ylim(-6,6)
  plt.quiver(x[:,0], x[:,1],ev[:,i].reshape(N,2)[:,0],ev[:,i].reshape(N,2)[:,1],label=str(ew[i]))
  plt.legend()
plt.show()

