from scipy import linspace,linalg,cosh
import matplotlib.pyplot as plt
import numpy as np


def diffop(N,dx):
    D = np.eye(N) 
    D = -2*D             # diagonal of 2nd order centered difference operator
    for i in range(N-1): # first upper and lower diagonals
      D[i,i+1] = 1  
      D[i+1,i] = 1  
    D /= dx**2           
    return D

hbar = 1.05471800e-34  #for demonstration
u=1.660539040e-27      #for demonstration
evolt = 1.60218e-19       # evolt = electronvolt 

a = 3.8 # radius in Angström

species = "He"  # choose species
#species = Ar

if (species == "He"): 
  m=4.002602  # mass of Helium
  V0 = 0.081  # set coefficient for LJ-potential for Helium in ev
elif (species == "Ar"):
  m=36.948  # mass of Argon
  V0 = 1.03   # set coefficient for LJ-potential for Argon in ev
else:
  print("no species specified, exiting")
  exit()

coeff0 = hbar**2/(2*m*u*(a*1e-10)**2*evolt)               #hbar**2/(2ma**2) in ev calculated directly

coeff = (1.054718**2/(2*1.66053904*m*a**2*1.60218))*1e-2  #hbar**2/(2ma**2) in ev avoiding small numbers

print("\nspecies: ", species)
print("\ncoefficient hbar**2/(2ma**2) in electronvolt:")
print(coeff0)
print(coeff)

l = 1   # set angular momentum quantum number
Nev =5  # number of eigenvectors
N = 500 # number of x-values
Nmax = 5 
Nmin = 0.85  # Nmin cannot be too small, otherwise the potential diverges (leading order ~ 1/r*12 at small r)
dx = (Nmax-Nmin)/N
x = np.linspace(Nmin,Nmax,num=N)


H = -diffop(N,dx) 

V=np.zeros(N)
rho = (1/x)**6
V=V0*(rho**2 - 2*rho) # Lennard-Jones potential, avoid taking 12^th power be setting rho = (a/x)**6 

for i in range(N):
      H[i,i] += V[i]        
      H[i,i] += coeff*l*(l+1)*(1/x[i])**2        # angular momentum term

ew,ev = linalg.eigh(H)

print("\n\n********** Eigenvalues of 3D-Schrödinger Eq for potential Lennard-Jones potential *************\n")

print("Angular momentum quantum number:", l)

for i in range(Nev):
  print(ew[i]) 

#plot
fig=plt.figure()
plt.plot(x,V)
plt.xlabel(r'$r$')
plt.ylabel(r'$V(r)$')

plt.show()
 
