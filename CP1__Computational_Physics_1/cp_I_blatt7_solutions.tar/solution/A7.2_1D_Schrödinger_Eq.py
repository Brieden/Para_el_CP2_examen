from scipy import linspace,linalg,cosh
import matplotlib.pyplot as plt
import numpy as np

def potential(x,N):
    V = np.eye(N)
    for i in range(N):
      V[i,i] *= -5/cosh(x[i]) # use units where a=1 and 2m/hbar**2 = 1
    return V


def diffop(N,dx):
    D = np.eye(N)        
    D = -2*D             # diagonal of 2nd order centered difference operator
    for i in range(N-1): # first upper and lower diagonals
      D[i,i+1] = 1  
      D[i+1,i] = 1  
    D /= dx**2           # use units where a=1 and 2m/hbar**2 = 1 
    return D             

Nev = 12 # number of eigenvectors to plot
N = 500  # number of x-values
Nmax = 10 
Nmin = -10
dx = (Nmax-Nmin)/N
x = np.linspace(Nmin,Nmax,num=N)

#print(x)

print(diffop(N,dx))

H = -diffop(N,dx) + potential(x,N)

ew,ev = linalg.eigh(H)

print("\n\n********** Eigenvalues of 1D-Schrödinger Eq for potential V(x) = 5/cosh(x) *************\n")

for i in range(Nev):
  print(ew[i]) 

#plot
fig=plt.figure()
for i in range(Nev):
  plt.plot(x,ev[:,i]+ew[i])

plt.xlabel(r'$x/a$')
plt.ylabel(r'$\psi(x/a)$')

plt.show()
 
