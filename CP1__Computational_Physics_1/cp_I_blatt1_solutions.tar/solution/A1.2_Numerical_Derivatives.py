# -*- coding: utf-8 -*-
from scipy import sin, cos, arange, logspace
import pylab as plt

# Define the three derivatives
def df_right(f,x,h):
    return (f(x+h) - f(x))/h

def df_left(f,x,h):
    return (f(x) - f(x-h))/h

def df_centered(f,x,h):
    return (f(x+h) - f(x-h))/2./h

# Calculate the differences between numerical and exact solution at x0
#n = arange(1,60,1.)
#h = 2**(-n)
h = logspace(-16,0,1000)
x0 = 1.

df_exact = -sin(x0) # Exact derivative is -sin(x)
dfr = abs(df_right(cos, x0, h) - df_exact)
dfl = abs(df_left(cos, x0, h) - df_exact)
dfc = abs(df_centered(cos, x0, h) - df_exact)

# Plot
plt.figure()
plt.loglog(h, dfr, 'xr',label='right')
plt.loglog(h, dfl, 'xb',label='left')
plt.loglog(h, dfc, 'xg',label='center')

plt.xlabel(r'h')
plt.ylabel(r'error')
plt.legend()

plt.show()
