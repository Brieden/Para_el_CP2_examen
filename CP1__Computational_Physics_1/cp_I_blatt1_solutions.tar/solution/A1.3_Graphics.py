from scipy import linspace,exp
import time
import matplotlib.pyplot as plt
from matplotlib import rc
#latex 
rc('font',**{'family':'sans-serif','sans-serif':['Helvetica']})
rc('text', usetex=True)



#fct definitions
def bisection_double(a,b,threshold,func):

    count = 0
    if (func(a)*func(b) < 0 and (b-a > 0)):
      midpoint = (a+b)/2
      while ((b-a)/2 > threshold and func(midpoint) != 0):
        fmidp = func(midpoint)
        count += 1  
        if (func(a)*func(midpoint) < 0):
           b=midpoint
        # Here we evaluation an if statement which is not necessary, 
        # see the function bisection_single
        elif (func(b)*func(midpoint) < 0):
           a=midpoint
        midpoint = (a+b)/2
      return midpoint
    else:
      print("No execution. Check interval")

def bisection_single(a,b,threshold,func):

    count = 0
    if (func(a)*func(b) < 0 and (b-a > 0)):
      midpoint = (a+b)/2
      while ((b-a)/2 > threshold and func(midpoint) != 0):
        count += 1  
        if (func(a)*func(midpoint) < 0):
           b=midpoint
        else:
           a=midpoint
        midpoint = (a+b)/2
      return midpoint
    else:
      print("No execution. Check interval")

f = lambda x: (x**2 - 2*x)*exp(-x)

#get zeros of force
print("Find zeros of the force in [-3,3]")
print("x_1 = ",bisection_double(-100,1.5, 1e-16,f))
print("x_2 = ",bisection_double(0.5,3, 1e-16,f))

#wallclock time comparison: bisection_double vs bisection_single
#start = time.time()
#for i in range(1,100):
#    bisection_double(-3,1.5, 1e-16,f) 
#end = time.time()
#print("bisection double 100 iterations: time = ", end-start, "s")

start = time.time()
for i in range(1,100):
    bisection_single(-3,1.5, 1e-16,f) 
end = time.time()
print("bisection single 100 iterations: time = ", end-start, "s")

#plotting
x = linspace(-1,10,1000)

potential = x**2*exp(-x)
force = f(x)
force_x = (-x**2 + 4*x -2)*exp(-x) 


fig = plt.figure();

#for latex text
plt.rc('text', usetex=True)
plt.rc('font', family='serif')

plt.xlabel(r'$x$', fontsize=16)
plt.ylabel(r'$f(x)$', fontsize=16)
plt.plot(x,potential,label = r'$V$')
plt.plot(x,force,label = r'$-\frac{dV}{dx}$')
plt.plot(x,force_x,label = r'$-\frac{d^2V}{dx^2}$')
plt.grid(True)
axes = plt.gca()
axes.set_ylim([-3,3])

plt.legend()
plt.show()

exit()
