# -*- coding: utf-8 -*-
# Determine smallest numerical resolution
# Check when (1+epsilon) != 1 for decreasing epsilon

# approach 1
epsilon = 1.
nSteps = 0
while(1. + epsilon != 1. and nSteps < 1000):
    epsilon /= 2 # Be careful, here the smallest epsilon that distinguishes 
                 # between 1 and 1+epsilon is divided by two one last time. 
    nSteps += 1
    print(nSteps, epsilon)

print("\nscheme 1: \n")
print("The smallest number epsilon such that 1 and (1+epsilon) \
can numerically be distinguished is {0:1.16e}".format(epsilon*2))
print("Epsilon so that 1 and (1+epsilon) are indistinguishable: {0:1.16e}".format(epsilon))

# approach 2
print("\nscheme 2: \n")
epsilon = 1.
epsilonOut = epsilon
de  = 1.0
nSteps = 0
while (nSteps < 10000):
  de /= 2
  nSteps += 1
  if ( 1. + epsilon != 1. ):
    epsilonOut = epsilon # Here, the last epsilonOut *is* the machine epsilon. 
    epsilon -= de

print("The smallest number epsilon such that 1 and (1+epsilon) \
can numerically be distinguished is {0:1.16e}".format(epsilonOut))
print("Hint: Even when the distinction is no more possible, epsilon itself isn't 0; epsilon/2 = {0:1.16e}".format(epsilonOut/2))
print("(epsilon == 0) is {0}".format(epsilonOut/2. == 0))
