# -*- coding: utf-8 -*-

from scipy import zeros,pi,sqrt,exp,maximum
import scipy as sci
import pylab as plt
from matplotlib import rc

# tex 
rc('font',**{'family':'sans-serif','sans-serif':['Helvetica']}) 
rc('text', usetex=True)

# Recursion relation for wave functions
def recur_wave(x, n):
    if (n==0): 
      return  pow(pi,-0.25)*exp(-x*x/2)
    elif(n==1):
      return sqrt(2)*x*pow(pi,-0.25)*exp(-x*x/2) 
    else:
      return 1/sqrt(n) * (sqrt(2) * x * recur_wave(x,n-1) - sqrt(n-1) * recur_wave(x,n-2)) 

xresolution = 1000
x = sci.linspace(-10,10,xresolution)  

nstates = 20

#plot probability densities for all states in one figure, shifted by n
fig = plt.figure()
plt.xlabel(r'$x/\sqrt{\hbar / (m\omega)}$',fontsize=16)
plt.ylabel(r'$|\psi_n|^2+n$',fontsize=16)
for i in range(0,nstates):
   plt.plot(x,i+recur_wave(x,i)**2, color = 'black')
plt.savefig("A3.1_Hermite_Polynomials.png")


#plot probability densities for all states in separate figures
fig = plt.figure()
plt.subplots_adjust(wspace=0.75,hspace=0.75)
for i in range(0,nstates):
   plt.subplot(5,5,i+1)
   plt.plot(x,recur_wave(x,i)**2)
   plt.title(r'$n = $ ' + str(i))
   plt.xlabel(r'$x/\sqrt{\hbar / (m\omega)}$')
   plt.ylabel(r'$|\psi_n(x)|^2$')
   plt.ylim(0,.6)

scale = 1.5
fig.set_size_inches((8*scale,8*scale))
plt.savefig("A3.1_Hermite_Polynomials2.png")

#compare against classical probability density for n = 20

x_0=sqrt(2*20 + 1)       #turning point = sqrt(2E_n), where E_n = 2n + 1 
                         # is the energy of the n-th excited state in units of hbar*omega 
x_def = x[abs(x) <= x_0] # interval of definition for pclass: pclass must be a real number 
pclass = 1/(pi*sqrt(x_0**2-x_def**2))

fig = plt.figure()
plt.plot(x,recur_wave(x,20)**2)
plt.plot(x_def,pclass, color = 'black')
plt.title(r'$n = 20$ ')
plt.xlabel(r'$x/\sqrt{\hbar / (m\omega)}$')
plt.ylabel(r'$|\psi_n(x)|^2$')
plt.ylim(0,.4)

#plt.show()

plt.savefig("A3.1_Hermite_Polynomials3.png")

exit()
