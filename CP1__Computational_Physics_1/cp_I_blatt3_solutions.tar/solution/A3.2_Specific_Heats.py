# -*- coding: utf-8 -*-

from scipy import zeros,pi,sqrt,exp
import scipy as sci
import numpy as np
import pylab as plt
from matplotlib import rc

# tex 
rc('font',**{'family':'sans-serif','sans-serif':['Helvetica']}) 
rc('text', usetex=True)

# function definitions

def Z(T,N):
    theta = 1 # Consider T in units of theta: T-> T/theta 
    z=0
    for i in range(0,N+1,1):
       z += (2*i+1)*exp(-i*(i+1)*theta/T)
    return z

def dZdT(T,N):
    theta = 1 
    z=0
    for i in range(0,N+1,1):
       z += i*(2*i+1)*(i+1)*1/T**2*exp(-i*(i+1)*theta/T)
    return z

def d2ZdT(T,N):
    theta = 1 
    z=0
    for i in range(0,N+1,1):
       z += i*(2*i+1)*(i+1)*(i*(i+1)/T**4 - 2/T**3)*exp(-i*(i+1)*theta/T)
    return z

T = sci.linspace(0.01,10,500) 
y = Z(T,100)
C_A = T/y*(2* dZdT(T,100) + T*(d2ZdT(T,100)-dZdT(T,100)**2/y))

tmax=len(T)-1
U = np.zeros(tmax+1)
C = np.zeros(tmax+1)

k=1 # Consider the normalised functions C -> C/k, 

# calculate derivatives of Z: 
# forward and backward differences at end points
U[0] = k*T[0]**2* 1/y[0] * (y[1]-y[0])/(T[1]-T[0])  
U[tmax] = k*T[tmax]**2* 1/y[tmax] * (y[tmax]-y[tmax-1])/(T[tmax]-T[tmax-1])  

C[0] = (C[1]-C[0])/(T[1]-T[0])  
C[tmax] = (C[tmax]-C[tmax-1])/(T[tmax]-T[tmax-1])  

# central difference in the middle of the array
for i in range(1,tmax-1):
  U[i] = k*T[i]**2* 1/y[i] * (y[i+1]-y[i-1])/(T[i+1]-T[i-1])  

for i in range(1,tmax-1):
  C[i] = (U[i+1]-U[i-1])/(T[i+1]-T[i-1])  


# tabulate C(T) 
print('T \t Z(T)')
for i in range(1,100,5):
  print(T[i],y[i])

fig = plt.figure()

plt.plot(T,C,marker='x',label = r'numerical')
plt.plot(T,C_A,label = r'analytical', color = 'red')
plt.xlim(0,3)
plt.ylim(0,1.2)
plt.xlabel(r'$T/\Theta$',fontsize=16)
plt.ylabel(r'$C_R/k_B$',fontsize=16)
plt.legend(loc=4)
#plt.show()
plt.savefig('A3.2_Specific_Heats.png')

exit()
