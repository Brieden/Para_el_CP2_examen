# -*- coding: utf-8 -*-

import scipy as sci
import pylab as plt

# The polynominal
def p(z, a):
    return z**3 + (a-1)*z - a

# Its derivative
def dp(z, a):
    return 3 * z**2 + (a-1)

# One Newton-Iterate
def Newton(z,a):
    return z - p(z,a)/dp(z, a)


def Iterates(rmin, rmax, imin, imax, a, specificRoot=False, root=0, nPoints=351, nMaxIter=30, epsilon=1e-2, bw=False):
# Plot the iterates needed for the Newton method to converge to a root
# Param:
# rmin, rmax, imin, imax: real and imaginary limits, respectively
# a: parameter to the polynomial p
# specificRoot: set True, if you want to look for convergence to only one specific root
# root: look for convergence to only this root - also set specificRoot = True!
# nPoints: number of data points in real and img direction, so total is nPoints**2
# nMaxIter: stop after n iterations
# bw: plot black and white, only converged/not converged (not number of iterates)
# epsilon: disk around a root which is said to be converged

    # Create computation grid z
    x = sci.linspace(rmin, rmax, nPoints)
    y = sci.linspace(imin, imax, nPoints)
    X,Y = sci.meshgrid(x,y*1j)
    z = X+Y # complex plane 

    # Determine number of iterates needed to converge to a root for each z
    i = 1 # total number of iterates
    nIter = sci.ones(z.shape) # number of iterates for each complex number z
    while i < nMaxIter:
        i+=1
        if not specificRoot:
            # no root specified -- check whether the value changed within the last iteration
            z1 = sci.copy(z)
            root = z1
            
        # Iterate one step
        z = Newton(z,a)
        # Mask converged gridpoints -- prevents them from getting iterated further
        # Points are considered converged if abs(z_n - z_n-1) < epsilon
        z = sci.ma.masked_array(z, abs(z-root) < epsilon)
        # Increase nIter of not-converged gridpoints
        nIter += (z.mask)*-1 + 1 # The mask is either true (==converged) or false - times -1 + 1 gives 1 or 0...
    
    # Mask nIter where the Newton-Method did not converge
    if bw: # Black and white plotting - normalize nIter to 1
        nIter = sci.ma.masked_array(nIter, nIter != nMaxIter) / nMaxIter
#    else:
#        nIter = sp.ma.masked_array(nIter, nIter == nMaxIter)
    print ("Finished evaluating ... plotting")
    
    plt.figure()
    plt.pcolor(x, y, nIter)
    if not bw:
        plt.colorbar()
    plt.axes().set_aspect('equal')

# uncomment the following as appropriate
# First part:
#Iterates(-5, 5, -5, 5, 0, True, root=1, nMaxIter=20, nPoints=701)
#Iterates(-5, 5, -5, 5, 0, epsilon=1e-4)

# Second part:
#Iterates(-1, 1, -1, 1, 0.32+1.64j, bw=True, nPoints = 701)
#Iterates(-1.5, 1, -1.5, 1, 0.32+1.64j)
Iterates(-40, 40, -40, 40, 0.32+1.64j)

# Iterate initial point located in the region which 
# does not converge: choose 0+0j
print("Choose initial guess in the region where the Newton method does not converge: z_0 = 0 + 0i")

iterates = [0]

z=0+0j
iterates.append(z)
for i in range(1,20):
    z = Newton(z,0.32+1.64j) # periodic orbit 
   # z = Newton(z,0.5+1.64j) # now we converge to a fixed point
    iterates.append(z)

for i in range(1,20):
  print(i,iterates[i])



print ("Invoking show")

plt.show()


# check roots:

#from numpy.roots(p)
#coeff = [1,0,a-1,-a]
#sci.roots(coeff)
