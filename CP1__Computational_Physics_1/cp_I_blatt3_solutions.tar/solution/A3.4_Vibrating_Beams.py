# -*- coding: utf-8 -*-
import scipy as sci
import scipy.optimize as opt
from scipy import sin, cos, sinh, cosh, pi
import pylab as plt


def A(kl, y):
    # y = x/l => kx = kly
    return (sin(kl) - sinh(kl)) * (cos(kl*y) - cosh(kl*y)) - \
           (cos(kl) - cosh(kl)) * (sin(kl*y) - sinh(kl*y))


# Find eigenvalues from eigenvalue-function
# Numerically determine eigenvalues with a bisection method
kl = sci.linspace(0, 10*pi, 1000) 	# Initial conditions

ev = [0]				# list of eigenvalues (0 is one)
f = lambda b: cos(b)*cosh(b) - 1 	# objective / eigenvalue function

for x in kl:
    x1 = x+2 			# Search in interval [x, x1]
    if ( f(x)*f(x1) > 0 ):	# no sign change, continue
        continue
    root = opt.bisect(f, x, x1)
    
    if len(ev) == 0:
        ev.append(root)         
    else: 			# don't add the same eigenvalue twice
        inev = False
        for t in ev:
            if abs(t-root) < 1e-4:
                inev = True
        if not inev:
            ev.append(root)     # collect eigenvalues into a list
    if len(ev) >= 6: 		# maximum number of eigenvalues to search
        break

ev = sci.array(ev)
print(ev)

# plot eigenvalue condition:
plt.figure()
x = sci.linspace(0,5,1000)
plt.plot(x,cos(x*(2*pi))*cosh(x*(2*pi)))
plt.plot(x,cos(x*(2*pi)))
plt.axhline(1,c='r')
plt.ylim(-2,2)
plt.xlabel('$\kappa l / 2\pi$')

#plt.show()

# plot first eigenmodes, rescaled to 1
plt.figure()
x = sci.linspace(0,1, 1e5)
i = 1
for b in ev:
    plt.subplot(2,3,i)
    plt.plot(x, A(b, x)/max(A(b,x).max(),0.1))
    plt.title("$\kappa_{0}l = {1}$".format(i,b))
    plt.ylim(-1,1)
    plt.xlabel('$x/l$')
    i+=1

plt.show()

