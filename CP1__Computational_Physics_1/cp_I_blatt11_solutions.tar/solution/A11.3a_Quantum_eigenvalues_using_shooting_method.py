import scipy as sci
from scipy.integrate import odeint
from scipy.optimize import fsolve,bisect

import pylab as plt

# harmonic oscillator, renormalized, see lecture

def SEQ(y,x,V,E):
  return (y[1],(V(x)-2*E)*y[0])

def V_harm(x):
  return x*x

# psi(L,E):
def psi_L(E,y0,L,V):
  x = sci.linspace(0,L,1e3)
  y = odeint(SEQ,y0,x,args=(V,E))
  return y[-1,0] # return value of wave function at L

# plot potential + exact energies:
plt.figure()
y = sci.linspace(0,10,100)
plt.plot(sci.sqrt(y),y,'r-') # potential
for i in range(10):
  plt.axhline(0.5+i)         # exact energies E_n = 1/2 + n
plt.title('potential and energy levels')
plt.xlabel('$x$')
plt.ylabel('$V(x)$')
plt.show()


# minimum requirement for L: L > sqrt(E) (classically forbidden zone)
# we will integrate only over [0,L] instead of over [-L'L], making use 
# of the (anti)symmetry of the wave functions

# symmetric solutions:
# psi(x) = psi(-x)
# psi(0) = 1, psi'(0) = 0, E variable, psi(L) == 0

# antisymmetric solutions:
# -psi(x) = psi(-x)
# psi(0) = 0, psi'(0) = 1, E variable, psi(L) == 0

def eigvals(L,n,V):
  sym = True
  E0 = 0.1
  plt.figure()
  x = sci.linspace(0,L,1000)
  plt.plot(x,V(x),'r-')
  
  for i in range(n):
    # n first eigenvalues
    if (sym):
      y0 = (1.,0.)	# symmetric i.c.
    else:
      y0 = (0.,1.)	# antisymm. i.c.
    
    E = fsolve(psi_L,E0,args=(y0,L,V)) # returns E such that psi(L) = 0; y0,L,V held fixed
    E_ref = 0.5 + i
    #print("E_{0}: {1}, deltaE: {2:1.6e}".format(i,E,E-E_ref))
    print("E_{0}: {1}, deltaE: {2}".format(i,E,E-E_ref)) # print eigenvalue and difference to reference value
   
    plt.axhline(E,c='0.5')
    psi = odeint(SEQ, y0, x, args=(V, E))[:,0] # calculate eigenfunction for the eigenvalue E
    psi *= 0.5 / max(psi) # normalise 
    plt.plot(x,psi+E,'b-')
    
    sym = not sym # alternate between symmetric and antisymmetric function to get the right order of eigenvalues and eigenfunctions
    E0 = E
  plt.ylim(0,n+0.5)
  plt.xlabel('$x$')
  plt.ylabel(r'$V \quad | \quad \Psi_i+E_i$')
  plt.title('potential and eigenfunctions')
  plt.show()

# first two eigenvalues:
eigvals(4.1,2,V_harm)

# first 10 eigenvalues:
eigvals(6.2,10,V_harm)


# alternatively:
# integrate from classically forbidden to classically forbidden zone
# takes longer to compute

def psi_forbidden(E,y0,L,V):
  x = sci.linspace(-L,L,1e3)
  y = odeint(SEQ,y0,x,args=(V,E))
  return y[-1,0]

def eigvals_forbidden(L,n,V):
  y0 = (0.,1.)
  E0 = 0.05
  dE = 0.1
  plt.figure()
  x = sci.linspace(-L,L,1000)
  plt.plot(x,V(x),'r-')
  yEndOld = odeint(SEQ,y0,x,args=(V,E0))[-1,0]   #psi(L,E0)
  i = 0
  while (i < n):
    E0 += dE
    yEnd = odeint(SEQ,y0,x,args=(V,E0))[-1,0]    #psi(L,E0+dE0)
    if (yEnd*yEndOld) < 0:		         # if sign change in psi between E0 and E0+dE0, find value of E for which psi(L,E)=0 by bisection
      E = bisect(psi_forbidden,E0-dE,E0,args=(y0,L,V))    
      E_ref = 0.5 + i
      print("E_{0}: {1}, deltaE: {2:1.6e}".format(i,E,E-E_ref)) # print eigenvalue and difference to reference value
      plt.axhline(E,c='0.5')
      psi = odeint(SEQ, y0, x, args=(V, E))[:,0]
      psi *= 0.5 / max(psi) #normalise
      plt.plot(x,psi+E,'b-')
      i += 1
    yEndOld = yEnd
  plt.ylim(0,n+0.5)
  plt.xlabel('$x$')
  plt.ylabel(r'$V \quad | \quad \Psi_i+E_i$')
  plt.title('potential and eigenfunctions')
  plt.show()

# first two eigenvalues:
eigvals_forbidden(4.1,2,V_harm)

# first 10 eigenvalues:
eigvals_forbidden(6.2,10,V_harm)


