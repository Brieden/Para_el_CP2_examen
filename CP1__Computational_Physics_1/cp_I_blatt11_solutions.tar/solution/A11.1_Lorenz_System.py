import scipy as sci
import scipy.linalg as linalg
from scipy.integrate import odeint
from scipy.optimize import fsolve
from scipy.linalg import eigvals

import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

def lorenz(x,t,s,b,r):
  return [s*(x[1]-x[0]),r*x[0]-x[1]-x[0]*x[2],x[0]*x[1]-b*x[2]]

# Jacobi matrix
def dl(x,t,s,b,r):
  return [ [ -s     ,   s  , 0     ],
	   [ r-x[2] , -1.  , -x[0] ],
	   [ x[1]   , x[0] , -b    ] ]


s = 10.
b = 8./3.



# trajectories for r=28

r = 28.

x0 = [0,0,1.]
x0 = [1.,1.,1.]

t = sci.linspace(0,100,10000)

x = odeint(lorenz,x0,t,(s,b,r))

# 2d-plots:
plt.figure(figsize=(22,6))
plt.subplot(131)
plt.plot(x[:,0],x[:,1])
plt.xlabel('$x$')
plt.ylabel('$y$')
plt.subplot(132)
plt.plot(x[:,0],x[:,2])
plt.xlabel('$x$')
plt.ylabel('$z$')
plt.subplot(133)
plt.plot(x[:,1],x[:,2])
plt.xlabel('$y$')
plt.ylabel('$z$')

# 3d-plot:
fig = plt.figure()
ax = fig.gca(projection='3d')
ax.plot(x[:,0],x[:,1],x[:,2])
ax.set_xlabel('$x$')
ax.set_ylabel('$y$')
ax.set_zlabel('$z$')

# time series:
plt.figure(figsize=(22,6))
plt.subplot(311)
plt.plot(t,x[:,0])
plt.xlabel('$t$')
plt.ylabel('$x$')
plt.subplot(312)
plt.plot(t,x[:,1])
plt.xlabel('$t$')
plt.ylabel('$y$')
plt.subplot(313)
plt.plot(t,x[:,2])
plt.xlabel('$t$')
plt.ylabel('$z$')

plt.show()

input("Press enter to proceed to calculation of the stability of fixed points")

#************End of material for Exercise************
# The following contains code to assess the stability of the 
# three fixed points depending on r (part 1) and a calculation
# of Lyapunov exponents (part 2)


# part 1: Stability of fixed points depending on r
r= 12. # example value, only used to print FPs once 

# fixed points (calculated analytically)
x0_1 = [0.,0.,0.]
x0_2 = [sci.sqrt(b*r-b),sci.sqrt(b*r-b),r-1]
x0_3 = [-sci.sqrt(b*r-b),-sci.sqrt(b*r-b),r-1]

print("Fixed points for r = {0}:".format(r))
print("x1= {0}:".format(x0_1))
print("x2= {0}:".format(x0_2))
print("x3= {0}:".format(x0_3))

# for each r, get the eigenvalues with largest real part for each fixed point
rList = sci.linspace(1,30,300)
e1 = []
e2 = []
e3 = []

for r in rList:   
  x0_2 = [sci.sqrt(b*r-b),sci.sqrt(b*r-b),r-1]
  x0_3 = [-sci.sqrt(b*r-b),-sci.sqrt(b*r-b),r-1]
  ev = eigvals(dl(x0_1,0.,s,b,r))
  e1.append(ev.real.max())    # arrays hold eigenvalues with largest real part for each value of r 
  ev = eigvals(dl(x0_2,0.,s,b,r))
  e2.append(ev.real.max())
  ev = eigvals(dl(x0_3,0.,s,b,r))
  e3.append(ev.real.max())

# plot eigenvalues with largest real part as fct of r, stability changes when there is a zero-crossing
plt.plot(rList,e1) 
plt.plot(rList,e2)
plt.plot(rList,e3)
plt.xlabel('$r$')
plt.ylabel('$\max(Re(\lambda))$')
ax=plt.gca()
ax.axhline(0,color='black',linestyle='--' )
plt.show()

# determine change in stability ( Re(lambda_max) = 0)
def zeroSearch(r):
  x0_2 = [sci.sqrt(b*r-b),sci.sqrt(b*r-b),r-1]
  ev = eigvals(dl(x0_2,0.,s,b,r))
  return ev.real.max()

print("Instability for r > {0}".format(fsolve(zeroSearch,30.)[0])) # returns value of r for which max(Re(lambda)) = 0

input("Press enter to proceed to calculation of the Lyapunov exponent")

# part 2: Lyapunov exponent: Calculate the distance between two trajectories originating
# from initial conditions which were 'close by each other'

print("Lyapunov exponent for r= {0}".format(r))
# initial conditions
epsilon = 1e-11
x0 = [1,1.,1.]
y0 = [1. + epsilon,1.,1.] 

x = odeint(lorenz,x0,t,(s,b,r))
y = odeint(lorenz,y0,t,(s,b,r))

d = x-y
d = sci.array([linalg.norm(d[i,:]) for i in range(d.shape[0])])
plt.plot(t,d,'r.')
plt.semilogy()
plt.xlabel('$t$')
plt.ylabel('$\log (d)$')

plt.show()

# linear fit in appropriate interval in semilog coordinates:
z = sci.polyfit(t[1100:2700],sci.log(d)[1100:2700], 1)  # Least squares polynomial fit with degree 1, returns coefficients of polynomial 
p = sci.poly1d(z)                                       # constructs polynomial out of coefficients returned by the fit 
print("Lyapunov exponent: {0}".format(z[0]))

plt.plot(t,sci.log(d),'r.')
plt.plot(t,p(t),'g-')
plt.xlabel('$t$')
plt.ylabel('$\log (d)$')

plt.show()


input("Press enter to proceed to calculation at large r")
# part 3: increase r

r = 99.96	# torus-knot

print("Attractor for r= {0}".format(r))

x0 = [0,0,1.]
x0 = [1.,1.,1.]

t = sci.linspace(0,100,10000)

x = odeint(lorenz,x0,t,(s,b,r))

plt.figure(figsize=(22,6))
plt.subplot(131)
plt.plot(x[5000:,0],x[5000:,1])
plt.xlabel('$x$')
plt.ylabel('$y$')
plt.subplot(132)
plt.plot(x[5000:,0],x[5000:,2])
plt.xlabel('$x$')
plt.ylabel('$z$')
plt.subplot(133)
plt.plot(x[5000:,1],x[5000:,2])
plt.xlabel('$y$')
plt.ylabel('$z$')

plt.figure(figsize=(22,10))
plt.subplot(311)
plt.plot(t,x[:,0])
plt.xlabel('$t$')
plt.ylabel('$x$')
plt.subplot(312)
plt.plot(t,x[:,1])
plt.xlabel('$t$')
plt.ylabel('$y$')
plt.subplot(313)
plt.plot(t,x[:,2])
plt.xlabel('$t$')
plt.ylabel('$z$')


fig = plt.figure()
ax = fig.gca(projection='3d')
ax.plot(x[5000:,0],x[5000:,1],x[5000:,2])
ax.set_xlabel('$x$')
ax.set_ylabel('$y$')
ax.set_zlabel('$z$')

plt.show()




