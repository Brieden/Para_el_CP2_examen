import scipy as sci
from scipy.integrate import odeint
from scipy.optimize import fsolve,bisect

import pylab as plt

V0 = 5.

# Schrödinger equation:
def SEQ(y,x,V,E):
  return (y[1],2.*(V(x)-E)*y[0])

# Lennard-Jones potential:
def V_LJ(x):
  #V0 = 10.
  return V0*(1./x**12-2./x**6)

# Taylor expansion:
def V_approx(x):
  #V0 = 10.
  return V0*(-1. + 0.5*12.*6*(x-1)**2)

# harmonic approximation
def V_harm(x):
  #V0 = 10.
  return V0*(-1+36*x**2)


# plot potential:
plt.figure()
epsilon = 0.1
x = sci.linspace(epsilon,5,1000)
plt.plot(x,V_LJ(x),'r-',label='LJ')
plt.plot(x,V_approx(x),'b-',label='Taylor series approx.')
plt.plot(x,V_harm(x),'b--',label='harmonic approx.')

plt.title('potentials')
plt.xlabel('$x$')
plt.ylabel('$V(x)$')
plt.ylim(-10,10)
plt.show()



# psi(L,E):
def psi_L(E,y0,L,V,cutoff):
  x = sci.linspace(cutoff,L,1e5)
  y = odeint(SEQ,y0,x,args=(V,E))
  return y[-1,0]

# psi(0,E):
# start at x = L 
def psi_0(E,y0,L,V,cutoff):
  x = sci.linspace(L,cutoff,1e5)
  y = odeint(SEQ,y0,x,args=(V,E))
  return y[-1,0]



# minimum requirement for L: L in classically forbidden zone

# LJ-potential: NOT symmetric!!
# => integrate from classically forbidden zone to classically forbidden zone
# !! numerically unreliable in comparison to the previous method (there, geometrical considerations are hard-coded)

# LJ-potential diverges for x -> 0 => start at x = cutoff 

# for ground state: in classically forbidden zone: Psi = 0, Psi' != 0 (otherwise: only trivial solution)
# => start at x = cutoff << 1 ( V >> 0 => "deep" in classically forbidden zone )
# => integrate up to x = L >> 1

# alternatively: start at x = L, Psi(L) = 0, Psi'(L) = -1, integrate down to x = cutoff << 1


# ground state, starting at x=cutoff to x = L
cutoff = .5
L = 20.
y0 = [0.,1.]
E = bisect(psi_L,-9,-0.01,args=(y0,L,V_LJ,cutoff))
print("Energy: {0}".format(E))
x = sci.linspace(cutoff,L,1e3)
psi = odeint(SEQ, y0, x, args=(V_LJ, E))[:,0]  # psi 
#chi = odeint(SEQ, y0, x, args=(V_LJ, E))[:,1]  # psi'
psi *= 0.5 / max(psi)
#chi *= 0.5 / max(chi)

plt.figure()
plt.plot(x,psi+E,'b-')
#plt.plot(x,chi+E,'b-')
plt.plot(x,V_LJ(x),'r-')
plt.ylim(-6,5)
plt.title('integrated from $x=0.5$ to $x=L$')
plt.xlabel('$x$')
plt.ylabel(r'$V \quad | \quad \Psi_0+E_0$')


# ground state, starting at x=L to x=cutoff
y0 = [0.,-1.]
E = bisect(psi_0,-9,-0.01,args=(y0,L,V_LJ,cutoff))
print("Energy: {0}".format(E))
x = sci.linspace(L,cutoff,1e3)
psi = odeint(SEQ, y0, x, args=(V_LJ, E))[:,0]
#chi = odeint(SEQ, y0, x, args=(V_LJ, E))[:,1]
psi *= 0.5 / max(psi)
#chi *= 0.5 / max(chi)

plt.figure()
plt.plot(x,psi+E,'b-')
#plt.plot(x,chi+E,'b-')
plt.plot(x,V_LJ(x),'r-')
plt.title('integrated from $x=L$ to $x=0.5$')
plt.xlabel('$x$')
plt.ylabel(r'$V \quad | \quad \Psi_0+E_0$')
plt.ylim(-6,5)

plt.show()

# approximate solution (harmonic approximation of the LJ potential):

y0 = [1.,0.]
cutoff = 0.
L = 1.
E0 = -9

E = fsolve(psi_L,E0,args=(y0,L,V_harm,cutoff))
print("Approximate potential:\nEnergy: {0}".format(E))


