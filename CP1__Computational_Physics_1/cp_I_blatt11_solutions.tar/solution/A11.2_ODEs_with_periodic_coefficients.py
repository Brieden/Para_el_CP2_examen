import scipy as sci
import scipy.linalg as linalg
from scipy.integrate import odeint
from scipy.optimize import bisect

import pylab as plt

# \ddot x = -f(t) x
def mathieu(x, t, a, q ):
    # set 2nd order eq. up as 2D system of 1st-order eqs. 
    return [x[1], - ( a + q*sci.cos(2*t) ) * x[0] ]

    
# plot a trajectory:
a = 1.5
q = 0.2
T = 20.*sci.pi
t = sci.linspace(0,T,100)
x0 = [2,1]

x  = odeint(mathieu, x0, t, args=(a,q))

plt.plot(t,x[:,0],'r-',label='$x$')
plt.plot(t,x[:,1],'b-',label='$\dot x$')
plt.xlabel('$t$')
plt.ylabel('$x(t), \ \dot{x}(t)$')
plt.legend()

plt.show()
 
    

# compute trace(A(a,q))
def Trace(a,q=0.2):
    T = sci.pi
    t = (0,T)
    
    x1 = odeint(mathieu, [1.,0.], t, args=(a,q))  # get the fundamental solution for x0 = 1, dot(x)0 = 0 
    x2 = odeint(mathieu, [0.,1.], t, args=(a,q))  # get the fundamental solution for x0 = 0, dot(x)0 = 1 
    A = sci.zeros( [2,2] )
    A[:,0] = x1[-1,:]   # store x1(T=pi),dot(x1(T=pi) in first column
    A[:,1] = x2[-1,:]   # store x2(T=pi),dot(x2(T=pi) in second column 
    #  print(linalg.det(A))
    #  print(A)
    return A[0,0] + A[1,1]

# compute point where stability changes: find a such that |Trace(a,q))|=2
def computeBifu(amin,amax,q=0.2):
   critical = lambda a,q=0.2: abs(Trace(a,q))-2 
   return bisect(critical,amin,amax,q)

# plot trace as a function of a
def PlotTrace(amin, amax,q=0.2):
    print("q = {0}; Critical points:".format(q))
    aArray = sci.linspace(amin, amax, 1000)
    trArray = sci.zeros(aArray.shape)
    for i in range(len(aArray)):
        trArray[i] = Trace(aArray[i],q)
    # print(trArray)
    # get exact point where stability changes:
    for i in range(len(aArray)-1):
      if ( (abs(trArray[i])-2)*(abs(trArray[i+1])-2) < 0 ):
	#print(computeBifu(aArray[i],aArray[i+1],q))
        bif = computeBifu(aArray[i],aArray[i+1],q)
        print(bif)
 
    plt.figure()
    plt.xlabel('a')
    plt.ylabel('tr(A)')
    plt.plot(aArray, trArray, '-r', label ='q = {0}'.format(q))
    plt.legend()
    if min(trArray) < -2:
        plt.axhline(-2)
    if max(trArray) > 2:
        plt.axhline(2)

PlotTrace(0,10)
PlotTrace(0,10,2.0)

plt.show()


# plot tr(A) as function of a and q
def PlotTrace2d(amin,amax,qmin,qmax):
  aArray = sci.linspace(amin, amax, 100)
  qArray = sci.linspace(qmin, qmax, 10)
  A,Q = sci.meshgrid(aArray,qArray)
  tr = sci.copy(A)
  for i in range(A.shape[0]):
    for j in range(A.shape[1]):
      tr[i][j] = Trace(A[i][j],Q[i][j])
  plt.figure()
  plt.title('tr(A)')
  plt.contourf(A,Q,tr,levels=[-2,0,2])	# change levels for more details
  plt.colorbar()
  plt.contour(A,Q,tr,levels=[-2,2])
  plt.xlabel("a")
  plt.ylabel("q")


PlotTrace2d(0,10,0,2)

plt.show()


